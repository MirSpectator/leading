<template>
	<div>
		<h2>你好啊  大哥们</h2>
		<input v-model="name"></input>
		<h2>{{name}}</h2>
	    <router-view></router-view>
		<div class="alert alert-dark" role="alert">
		  A simple dark alert—check it out!
		</div>
		<button type="button" class="btn btn-default" aria-label="Left Align">
		  <span class="glyphicon glyphicon-align-left" aria-hidden="true"></span>
		</button>
		
		<button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="Tooltip on top">
		  Tooltip on top
		</button>
		<button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="right" title="Tooltip on right">
		  Tooltip on right
		</button>
		<button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="bottom" title="Tooltip on bottom">
		  Tooltip on bottom
		</button>
		<button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="left" title="Tooltip on left">
		  Tooltip on left
		</button>
		
		
		<div class="container">
		        <div class="row">
		            <div class="col-md-4">
		                <p><img src=<%= require("./images/bootstrap.png")%>/></p>
		            </div>
		            <div class="col-md-8">
		                <h1>Webpack 3 and Twitter Bootstrap</h1>
		                <h2>How to configure Webpack 3 to load Twitter Bootstrap SCSS and JavaScript?</h2>
		                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
		                    Launch demo modal
		                </button>
		
		                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		                    <div class="modal-dialog" role="document">
		                        <div class="modal-content">
		                            <div class="modal-header">
		                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		                                <h4 class="modal-title" id="myModalLabel">Modal title</h4>
		                            </div>
		                            <div class="modal-body">
		                                <p>Some text goes here.</p>
		                            </div>
		                            <div class="modal-footer">
		                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		                                <button type="button" class="btn btn-primary">Save changes</button>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				name: "王振鹏",
				isRouter: true,
			}
		},
		created() {
			$(function () {
			  $('[data-toggle="tooltip"]').tooltip()
			})
		},
		methods: {
		  
		}
	}
</script>

<style>
	@import url("utils/css/test.css");
	h2{
		color: red;
	}
</style>
