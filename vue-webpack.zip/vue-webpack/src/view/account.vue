<template>
	<div>
		<p>我是account页面</p>
		<button type="button" @click="go">登录</button>
		<router-link to="/account/login">Login</router-link>
		<router-link to="/account/register">register</router-link>
		<router-link to="../goodslist">登录</router-link>
		<router-view></router-view>
		<ul class="nav nav-pills">
		<li role="presentation" class="active"><a href="#">Home</a></li>
		<li role="presentation"><a href="#">Profile</a></li>
		<li role="presentation"><a href="#">Messages</a></li>
		</ul>
		<div class="alert alert-primary" role="alert">
		  A simple primary alert—check it out!
		</div>
		<div class="alert alert-secondary" role="alert">
		  A simple secondary alert—check it out!
		</div>
		<div class="alert alert-success" role="alert">
		  A simple success alert—check it out!
		</div>
		<div class="alert alert-danger" role="alert">
		  A simple danger alert—check it out!
		</div>
		<div class="alert alert-warning" role="alert">
		  A simple warning alert—check it out!
		</div>
		<div class="alert alert-info" role="alert">
		  A simple info alert—check it out!
		</div>
		<div class="alert alert-light" role="alert">
		  A simple light alert—check it out!
		</div>
		<div class="alert alert-dark" role="alert">
		  A simple dark alert—check it out!
		</div>
		
		<ul class="nav">
		  <li class="nav-item">
		    <a class="nav-link active" href="#">Active</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#">Link</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link" href="#">Link</a>
		  </li>
		  <li class="nav-item">
		    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
		  </li>
		</ul>
	</div>
</template>

<script>
	export default {
		name: 'account',
		data() {
			return {
				name:'王振鹏'
			}
		},
		created() {
			console.log("789");
			console.log($(document.body));
			console.log(window.$);
			$("body").append("<div>hello world</div>")
		},
		methods: {
			go () {
				 this.$router.push({ name: '/account/login' })
			}
		}
	}
</script>

<style>
</style>
