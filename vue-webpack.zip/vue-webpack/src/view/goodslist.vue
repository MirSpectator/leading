<template>
	<h2>我是goodslist页面</h2>
</template>

<script>
	export default {
		name: 'goodslist',
		data() {
			return {
				name:'王振鹏'
			}
		},
		methods: {
			
		}
	}
</script>

<style>
</style>
