<template>
    <div >
		<h2>我的vue文件</h2>
	</div>
	
</template>

<script>
	export default {
		name: 'index',
		data() {
			return {
				name:'王振鹏'
			}
		},
		created () {
		
		},
		methods: {
			
		}
	}
</script>

<style scoped>
	
</style>
