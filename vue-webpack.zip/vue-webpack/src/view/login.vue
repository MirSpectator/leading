<template>
	<div>
		<h2>我是login页面</h2>
	</div>
</template>

<script>
	export default {
		name: 'login',
		data() {
			return {
				name:'王振鹏'
			}
		},
		methods: {
			
		}
	}
</script>

<style>
</style>
