<template>
	<h2>我是register页面</h2>
</template>

<script>
	export default {
		name: 'register',
		data() {
			return {
				name:'王振鹏'
			}
		},
		methods: {
			
		}
	}
</script>

<style>
</style>
